# EaseUtility SDK Integration

1. [Introduction](#introduction)

2. [Integration EaseUtility SDK](#integration)

    [2.1 Integrating the EaseUtility SDK in to project](#step1)

    [2.2 Initialize the EaseUtility SDK](#step2)

    [2.3 Android code obfuscation](#step5)

3. [Integration Notes](#note)

## <a name="introduction">1.Introduction</a>

- EaseUtility Android SDK supports Android API 15+.
- Please make sure you have added an app and at least one ad slot in EaseUtility Platform.

## <a name="integration">2.Integration EaseUtility SDK</a>  

### <a name="step1">2.1 Integrating the EaseUtility SDK in to project</a>

* Check SDK in the rar.

* Configure the module's build.gradle for basic functions：

``` groovy
    dependencies {
        compile files('libs/easeutility_xx.jar')
    }
```

* Configure AndroidManifest.xml

```xml
	<!--Necessary Permissions-->
	<uses-permission android:name="android.permission.INTERNET"/>
	<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

	<!--If your targetSdkVersion is 28, you need update <application> as follows:-->
  	<application
    	...  	
        android:usesCleartextTraffic="true"
        ...>
        ...
    </application>
```



## <a name="step2">2.2 Initialization</a>  

> Init the SDK in your Application as detailed below: 

**Please make sure to initialize EaseUtility SDK before doing anything.**

```java
final InitListener initListener = new InitListener() {
            @Override
            public void onSuccess() { }

            @Override
            public void onFailed(String error) {
                Log.e("EaseUtility", error);
                if (initCount > 2) return;
                EaseUtilitySDK.initialize(context, Config.slotIdReward, this);
                initCount++;
            }
        };
EaseUtilitySDK.initialize(context, "Your slotID", initListener);
```

**Set schema https**

```java
EaseUtilitySDK.setSchema(true);
```

## <a name="step3">2.3 Obfuscation Configuration</a> 
> If it needs to obfuscate the codes in building the project process, you should add the following codes into the proguard file:

``` java
    #for sdk
    -keep public class com.ease.utility.**{*;}
    -dontwarn com.ease.utility.**

    #for gaid
    -keep class **.AdvertisingIdClient$** { *; }

    #for js and webview interface
    -keepclassmembers class * {
        @android.webkit.JavascriptInterface <methods>;
    }
    
```


## <a name="note">3.Integration Notes</a>

	If you live in a country, such as China, which is forbidden google play, two prerequisites to get EaseUtility ads: 
> * GooglePlay has installed on your device.
> * Your device have connect to VPN.

≠≠≠


